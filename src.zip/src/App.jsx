import Index from "./index";
import Login from "./Login";
import Register from "./Register";
import Category from "./Category";
import Ticket from "./Ticket";
import Organize from "./Organize";
import Events from "./Events";
import PublicEvent from "./Public"
import PrivateEvent from "./Private"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/index" element={<Index />} />
        <Route path="/category" element={<Category />} />
        <Route path="/events" element={<Events />} /> {/* ✅ Add Events Route */}
        <Route path="/ticket" element={<Ticket />} />
        <Route path="/organize" element={<Organize />} />
        <Route path="/publicEvent" element={<PublicEvent />} />
        <Route path="/privateEvent" element={<PrivateEvent />} />


      </Routes>
    </Router>
  );
}

export default App;
