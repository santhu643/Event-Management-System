import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./Events.css";

function Events() {
  const location = useLocation();
  const navigate = useNavigate(); // Used for redirection
  const searchParams = new URLSearchParams(location.search);
  const category = searchParams.get("category");

  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showBooking, setShowBooking] = useState(false); // To check if it's a booking modal
  const [ticketCount, setTicketCount] = useState(1);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    fetch(`http://localhost/ems/backend.php?action=get_events&category=${category}`)
      .then((res) => res.json())
      .then((data) => setEvents(data))
      .catch((err) => console.error("Error fetching events:", err));
  }, [category]);

  const handleViewMore = (eventId) => {
    fetch(`http://localhost/ems/backend.php?action=get_event_details&event_id=${eventId}`)
      .then((res) => res.json())
      .then((data) => {
        setSelectedEvent(data);
        setShowBooking(false);
        new window.bootstrap.Modal(document.getElementById("eventModal")).show();
      })
      .catch((err) => console.error("Error fetching event details:", err));
  };  

  const handleBookTicket = (eventId) => {
    fetch(`http://localhost/ems/backend.php?action=get_event_details&event_id=${eventId}`)
      .then((res) => res.json())
      .then((data) => {
        setSelectedEvent(data);
        setShowBooking(true);
        setTicketCount(1);
        setTotalPrice(data.price);
        new window.bootstrap.Modal(document.getElementById("eventModal")).show();
      })
      .catch((err) => console.error("Error fetching event details:", err));
  };

  const increaseTickets = () => {
    setTicketCount((prev) => {
      const newCount = prev + 1;
      setTotalPrice(newCount * selectedEvent.price);
      return newCount;
    });
  };

  const decreaseTickets = () => {
    setTicketCount((prev) => {
      if (prev > 1) {
        const newCount = prev - 1;
        setTotalPrice(newCount * selectedEvent.price);
        return newCount;
      }
      return prev;
    });
  };

  const handlePayment = () => {
    setTimeout(() => {
      // Redirect to ticket page after "payment"
      navigate(`/ticket?event_id=${selectedEvent.id}&tickets=${ticketCount}`);
    }, 2000); // Simulating 2 seconds payment processing
  };

  return (
    <div className="events-container">
      <header className="custom-header">
        <div className="custom-header-bar">
          <div className="custom-container">
            <div className="custom-row">
              <div className="custom-col-left">
                <h1 className="custom-branding">
                  <a href="#">SanFest</a>
                </h1>
              </div>
              <div className="custom-col-right">
                <nav className="custom-navigation">
                  <ul className="custom-menu">
                    <li><a href="/index">Home</a></li>
                    <li><a href="/category">Events</a></li>
                    <li><a href="/organize">Organize</a></li>
                    <li><a href="#"><i className="fas fa-user-circle" style={{ fontSize: "25px" }}></i></a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="event-list">
        {events.length > 0 ? (
          events.map((event) => (
            <div key={event.id} className="event-card">
              <h3>{event.title}</h3>
              <p>{event.location} | {new Date(event.date_time).toDateString()}</p>
              <div className="event-buttons">
                <button className="view-btn" onClick={() => handleViewMore(event.id)}>View More</button>
                <button className="book-btn" onClick={() => handleBookTicket(event.id)}>Book Ticket</button>
              </div>
            </div>
          ))
        ) : (
          <p className="no-events">No events available in this category.</p>
        )}
      </div>

      {/* Bootstrap Modal for View More / Book Ticket */}
      <div className="modal fade" id="eventModal" tabIndex="-1" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header modal-black">
              <h5 className="modal-title">{selectedEvent?.title}</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div className="modal-body modal-white">
              {selectedEvent && !showBooking && (
                <>
                  <p><strong>Date:</strong> {new Date(selectedEvent.date_time).toDateString()}</p>
                  <p><strong>Location:</strong> {selectedEvent.location}</p>
                  <p><strong>Description:</strong> {selectedEvent.description}</p>
                  <p><strong>Price:</strong> ${selectedEvent.price}</p>
                  <p><strong>Max Attendees:</strong> {selectedEvent.max_attendees}</p>
                  <p><strong>Event Type:</strong> {selectedEvent.event_type === "public" ? "Public Event" : "Private Event"}</p>
                </>
              )}

              {selectedEvent && showBooking && (
                <div className="ticket-booking">
                  <p><strong>Price per Ticket:</strong> ${selectedEvent.price}</p>
                  <div className="ticket-counter">
                    <button className="btn btn-outline btn-circle" onClick={decreaseTickets}>-</button>
                    <span className="ticket-count">{ticketCount}</span>
                    <button className="btn btn-outline btn-circle" onClick={increaseTickets}>+</button>
                  </div>
                  <p className="total-price"><strong>Total Price:</strong> ${totalPrice}</p>
                </div>
              )}
            </div>

            <div className="modal-footer modal-black">
              {showBooking ? (
                <button type="button" className="btn btn-primary" onClick={handlePayment}>Proceed to Payment</button>
              ) : (
                <button type="button" className="btn btn-light" data-bs-dismiss="modal">Close</button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Events;
