import { useEffect } from "react";
import {Link} from "react-router-dom";





function Index(){
    useEffect(() => {
        const scripts = [
        
          "/js/jquery.js",
          "/js/masonry.pkgd.min.js",
          "/js/jquery.collapsible.min.js",
          "/js/swiper.min.js",
          "/js/jquery.countdown.min.js",
          "/js/circle-progress.min.js",
          "/js/jquery.countTo.min.js",
          "/js/custom.js",
        ];
    
        const scriptElements = scripts.map((src) => {
          const script = document.createElement("script");
          script.src = src;
          script.async = true;
          document.body.appendChild(script);
          return script;
        });
    
        return () => {
          scriptElements.forEach((script) => document.body.removeChild(script));
        };
      }, []);


    return(
        <>
   
         <header className="site-header">
        <div className="header-bar">
            <div className="container-fluid">
                <div className="row align-items-center">
                    <div className="col-10 col-lg-4">
                        <h1 className="site-branding flex">
                            <a href="#">SUNFEST</a>
                        </h1>
                    </div>

                    <div className="col-2 col-lg-8">
                        <nav className="site-navigation">
                            <div className="hamburger-menu d-lg-none">
                                <span></span>
                                <span></span>
                                <span></span>   
                                <span></span>
                            </div>

                            <ul>
                                <li><a href="#">Home</a></li>
                                <li><Link to="/category">Events</Link></li>
                                <li><Link to="/organize">Organize</Link></li>
                                <li><a href="#"><i className="fas fa-user-circle" style={{"fontSize":"25px"}}></i></a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div className="hero-content">
        <div className="container">
            <div className="row">
                <div className="col-12 offset-lg-2 col-lg-10">
                    <div className="entry-header">
                        <h2>Hello world!</h2>

                        <div className="entry-meta-date">
                            06.28.018
                        </div>
                    </div>

                    <div className="countdown flex flex-wrap justify-content-between" data-date="2018/06/06">
                        <div className="countdown-holder">
                            <div className="dday"></div>
                            <label>Days</label>
                        </div>

                        <div className="countdown-holder">
                            <div className="dhour"></div>
                            <label>Hours</label>
                        </div>

                        <div className="countdown-holder">
                            <div className="dmin"></div>
                            <label>Minutes</label>
                        </div>

                        <div className="countdown-holder">
                            <div className="dsec"></div>
                            <label>Seconds</label>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-12 ">
                    <div className="entry-footer">
                        <a href="#" className="btn">Buy Tickets</a>
                        <a href="#" className="btn current">See Lineup</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div className="content-section">
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <div className="lineup-artists-headline">
                        <div className="entry-title">
                            <p>JUST THE BEST</p>
                            <h2>The Lineup Artists-Headliners</h2>
                        </div>

                        <div className="lineup-artists">
                            <div className="lineup-artists-wrap flex flex-wrap">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/black-chick.jpg" alt=""/> </a>
                                </figure>

                                <div className="lineup-artists-description">
                                    <div className="lineup-artists-description-container">
                                        <div className="entry-title">
                                            Jamila Williams
                                        </div>

                                        <div className="entry-content">
                                            <p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
                                        </div>

                                        <div className="box-link">
                                            <a href=""><img src="images/box.jpg" alt=""/></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="lineup-artists-wrap flex flex-wrap">
                                <div className="lineup-artists-description">
                                    <figure className="featured-image d-md-none">
                                        <a href="#"> <img src="images/mathew-kane.jpg" alt=""/> </a>
                                    </figure>

                                    <div className="lineup-artists-description-container">
                                        <div className="entry-title">
                                            Sandra Superstar
                                        </div>

                                        <div className="entry-content">
                                            <p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
                                        </div>

                                        <div className="box-link">
                                            <a href="#"><img src="images/box.jpg" alt=""/></a>
                                        </div>
                                    </div>
                                </div>

                                <figure className="featured-image d-none d-md-block">
                                    <a href="#"> <img src="images/mathew-kane.jpg" alt=""/> </a>
                                </figure>
                            </div>

                            <div className="lineup-artists-wrap flex flex-wrap">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/eric-ward.jpg" alt=""/> </a>
                                </figure>

                                <div className="lineup-artists-description">
                                    <div className="lineup-artists-description-container">
                                        <div className="entry-title">
                                            DJ Crazyhead
                                        </div>

                                        <div className="entry-content">
                                            <p>Quisque at erat eu libero consequat tempus. Quisque mole stie convallis tempus. Ut semper purus metus, a euismod sapien sodales ac. Duis viverra eleifend fermentum. </p>
                                        </div>

                                        <div className="box-link">
                                            <a href="#"> <img src="images/box.jpg" alt=""/></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col-12">
                    <div className="the-complete-lineup">
                        <div className="entry-title">
                            <p>JUST THE BEST</p>
                            <h2>The Complete Lineup</h2>
                        </div>

                        <div className="row the-complete-lineup-artists">
                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-1.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Miska Smith</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-2.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Hayley Down</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-3.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>The Band Song</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-4.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Pink Machine</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-5.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Brasil Band</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-6.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Mickey</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-7.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>DJ Girl</h2>
                            </div>

                            <div className="col-6 col-md-4 col-lg-3 artist-single">
                                <figure className="featured-image">
                                    <a href="#"> <img src="images/image-8.jpg" alt=""/> </a>
                                    <a href="#" className="box-link"> <img src="images/box.jpg" alt=""/> </a>
                                </figure>

                                <h2>Stan Smith</h2>
                            </div>
                        </div>

                        <div className="row justify-content-center">
                            <div className="see-complete-lineup">
                                <div className="entry-footer">
                                    <a href="#" className="btn">See all lineup</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="homepage-next-events">
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        <div className="entry-title">
                            <p>JUST THE BEST</p>
                            <h2>Our Next Events</h2>
                        </div>
                    </div>
                </div>
            </div>

            <div className="next-event-slider-wrap">
                <div className="swiper-container next-event-slider">
                    <div className="swiper-wrapper">
                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-1.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>

                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-2.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>

                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-3.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>

                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-1.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>

                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-2.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>

                        <div className="swiper-slide">
                            <div className="next-event-content">
                                <figure className="featured-image">
                                    <img src="images/next-event-3.jpg" alt=""/>

                                    <a href="#" className="entry-content flex flex-column justify-content-center align-items-center">
                                        <h3>Welcoming Party 2018</h3>
                                        <p>Green Palace, 22 Street, 23-28, Los Angeles California</p>
                                    </a>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="swiper-button-next">
                    <img src="images/button.png" alt=""/>
                </div>
            </div>
        </div>

        <div className="home-page-last-news">
            <div className="container">
                <div className="header">
                    <div className="entry-title">
                        <p>JUST THE BEST</p>
                        <h2>Our Last News</h2>
                    </div>
                </div>

                <div className="home-page-last-news-wrap">
                    <div className="row">
                        <div className="col-12 col-md-6">
                            <figure className="featured-image">
                                <a href="#"> <img src="images/news-image-1.jpg" alt="fesival+celebration"/> </a>
                            </figure>

                            <div className="box-link-date">
                                <a href="#">03.12.18</a>
                            </div>

                            <div className="content-wrapper">
                                <div className="entry-content">
                                    <div className="entry-header">
                                        <h2><a href="#">10 Festival Tips</a></h2>
                                    </div>

                                    <div className="entry-meta">
                                        <span className="author-name"><a href="#"> By James Williams</a></span>
                                        <span className="space">|</span>
                                        <span className="comments-count"><a href="#">3 comments</a></span>
                                    </div>

                                    <div className="entry-description">
                                        <p>Quisque at erat eu libero consequat tempus.
                                            Quisque mole stie convallis tempus.
                                            Ut semper purus metus, a euismod sapien sodales ac.
                                            Duis viverra eleifend fermentum.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-12 col-md-6">
                            <figure className="featured-image">
                                <a href="#"> <img src="images/news-image-1.jpg" alt="fesival+celebration"/> </a>
                            </figure>

                            <div className="box-link-date">
                                <a href="">03.12.18</a>
                            </div>

                            <div className="content-wrapper">
                                <div className="entry-content">
                                    <div className="entry-header">
                                        <h2><a href="#">New event calendar for this year</a></h2>
                                    </div>

                                    <div className="entry-meta">
                                        <span className="author-name"><a href="#">By James Williams</a></span>
                                        <span className="space">|</span>
                                        <span className="comments-count"><a href="#">3 comments</a></span>
                                    </div>

                                    <div className="entry-description">
                                        <p>Quisque at erat eu libero consequat tempus.
                                            Quisque mole stie convallis tempus.
                                            Ut semper purus metus, a euismod sapien sodales ac.
                                            Duis viverra eleifend fermentum.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="footer-cover-title flex justify-content-center align-items-center">
            <h2>SUNFEST</h2>
        </div>

        <div class="footer-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="entry-title">
                            <a href="#">SUNFEST</a>
                        </div>

                        <div class="entry-mail">
                            <a href="#">SAYHELLO@SUNFEST.COM</a>
                        </div>

                        <div class="copyright-info">
                            
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>

                        </div>

                        <div class="footer-social">
                            <ul class="flex justify-content-center align-items-center">
                                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                                <li><a href="#"><i class="fab fa-behance"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    </>

    )
}

export default Index