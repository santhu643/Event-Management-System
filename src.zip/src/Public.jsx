import React, { useState } from "react";
import "./public.css"; // Import CSS for styling
import Topbar from "./components/Topbar"; // Importing the TopBar

function PublicEvent() {
  const [eventData, setEventData] = useState({
    title: "",
    description: "",
    category: "",
    location: "",
    date_time: "",
    max_attendees: "",
    price: "0.00",
    event_type: "public", // Always "public"
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEventData({ ...eventData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost/ems/backend.php?action=register_event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(eventData),
      });

      const result = await response.json();
      if (result.status === 200) {
        setMessage("🎉 Event Added Successfully!");
        setEventData({
          title: "",
          description: "",
          category: "",
          location: "",
          date_time: "",
          max_attendees: "",
          price: "0.00",
          event_type: "public",
        });
      } else {
        setMessage("⚠️ Failed to Add Event: " + result.message);
      }
    } catch (error) {
      console.error("Error:", error);
      setMessage("⚠️ Something went wrong.");
    }
  };

  return (
    <div>
      {/* ✅ TopBar Added */}
      <Topbar />

      <div className="public-event-container">
        <h2>📢 Register a Public Event</h2>
        {message && <div className="message-box">{message}</div>}

        <form onSubmit={handleSubmit}>
          <label>Event Title</label>
          <input type="text" name="title" required value={eventData.title} onChange={handleChange} />

          <label>Description</label>
          <textarea name="description" required value={eventData.description} onChange={handleChange}></textarea>

          <label>Category</label>
          <select name="category" required value={eventData.category} onChange={handleChange}>
            <option value="">Select Category</option>
            <option value="music">Music</option>
            <option value="art">Art</option>
            <option value="conference">Conference</option>
            <option value="sports">Sports</option>
            <option value="tech">Tech</option>
            <option value="workshops">Workshops</option>
          </select>

          <label>Location</label>
          <input type="text" name="location" required value={eventData.location} onChange={handleChange} />

          <label>Event Date & Time</label>
          <input type="datetime-local" name="date_time" required value={eventData.date_time} onChange={handleChange} />

          <label>Maximum Attendees</label>
          <input type="number" name="max_attendees" required value={eventData.max_attendees} onChange={handleChange} />

          <label>Ticket Price ($)</label>
          <input type="number" name="price" step="0.01" required value={eventData.price} onChange={handleChange} />

          <button type="submit">Submit Event</button>
        </form>
      </div>
    </div>
  );
}

export default PublicEvent;
