import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import jsPDF from "jspdf";

function Ticket() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);

  const eventId = searchParams.get("event_id");
  const tickets = searchParams.get("tickets");

  const [event, setEvent] = useState(null);

  useEffect(() => {
    fetch(`http://localhost/ems/backend.php?action=get_event_details&event_id=${eventId}`)
      .then((res) => res.json())
      .then((data) => setEvent(data))
      .catch((err) => console.error("Error fetching event:", err));
  }, [eventId]);

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("Event Ticket", 80, 20);
    doc.setFontSize(14);
    doc.text(`Event: ${event?.title}`, 20, 40);
    doc.text(`Location: ${event?.location}`, 20, 50);
    doc.text(`Date: ${new Date(event?.date_time).toDateString()}`, 20, 60);
    doc.text(`Tickets: ${tickets}`, 20, 70);
    doc.text("Enjoy your event!", 20, 90);
    doc.save("Event_Ticket.pdf");
  };

  return (
    <div className="ticket-container">
      <h2>🎟 Event Ticket</h2>
      {event ? (
        <div className="ticket-details">
          <p><strong>Event:</strong> {event.title}</p>
          <p><strong>Location:</strong> {event.location}</p>
          <p><strong>Date:</strong> {new Date(event.date_time).toDateString()}</p>
          <p><strong>Tickets:</strong> {tickets}</p>
          <button onClick={generatePDF} className="download-btn">Download Ticket</button>
        </div>
      ) : (
        <p>Loading ticket...</p>
      )}
    </div>
  );
}

export default Ticket;
