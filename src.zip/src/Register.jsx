import "./assets/css/login.css";
import "./assets/css/gfonts.css";
import {Link} from "react-router-dom";
import {useState,useEffect} from "react";
import { useNavigate } from "react-router-dom";



function Register() {
    const navigate = useNavigate();
    const[name,setName] = useState("");
    const[email,setEmail] = useState("");
    const[pass,setPass] = useState("");
    const[cpass,setCpass] = useState("");

    function reg(e){
        e.preventDefault();
        const data = {name,email,pass};
        fetch("http://localhost/ems/backend.php?action=register",{
            method:"POST",
            headers:{"Content-Type":'application/json'},
            body:JSON.stringify(data),
            
        })
        .then((response)=>response.json())
        .then((data)=>{
            if(data.status==200){
                alert("registered")
                navigate("/");

            }
            else{
                alert("Please Register Again");
            }
        })
    }


    return (
        <div id="logcss">
            <section >
                <form>
                    <h1>Register</h1>
                    <div className="inputbox">
                        <ion-icon name="person-outline"></ion-icon>
                        <input type="text" value={name} onChange={(e)=>setName(e.target.value)} required />
                        <label>Username</label>
                    </div>
                    <div className="inputbox">
                        <ion-icon name="mail-outline"></ion-icon>
                        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required />
                        <label>Email</label>
                    </div>
                    <div className="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" value={pass} onChange={(e)=>setPass(e.target.value)} required />
                        <label>Password</label>
                    </div>
                    <div className="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" value={cpass} onChange={(e)=>setCpass(e.target.value)} required />
                        <label>Confirm Password</label>
                    </div>
                   
                    <button onClick={reg}>Register</button>
                    <div className="register">
                        <p>Already have an account? <Link to="/">Login</Link></p>
                    </div>
                </form>
            </section>
        </div>
    );
}

export default Register;
