import React from "react";
import { useNavigate } from "react-router-dom";
import "./organize.css"; // Using the same CSS for consistency
import {Link} from "react-router-dom";
     

function Organize() {
  const navigate = useNavigate();

  return (
    <div className="category-container">
      {/* Top Bar (Same as Category Page) */}
      <header className="custom-header">
        <div className="custom-header-bar">
          <div className="custom-container">
            <div className="custom-row">
              <div className="custom-col-left">
                <h1 className="custom-branding">
                  <a href="#">SanFest</a>
                </h1>
              </div>

              <div className="custom-col-right">
                <nav className="custom-navigation">
                  <div className="custom-hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>

                  <ul className="custom-menu">
                    <li><Link to="/index">Home</Link></li>
                    <li><Link to="/category">Events</Link></li>
                    <li><Link to="/organize">Organize</Link></li>
                    <li><a href="#"><i className="fas fa-user-circle" style={{ fontSize: "25px" }}></i></a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Two Big Cards in Center */}
      <div className="organize-cards-container">
        <div className="organize-card" onClick={() => navigate("/publicEvent")}>
          <img src="images/public.jpg" alt="Public Event" />
          <h2>Public Event</h2>
          <p>Anyone can join your event</p>
        </div>

        <div className="organize-card" onClick={() => navigate("/privateEvent")}>
          <img src="images/private.jpg" alt="Private Event" />
          <h2>Private Event</h2>
          <p>Invite-only event with restricted access</p>
        </div>
      </div>
    </div>
  );
}

export default Organize;
