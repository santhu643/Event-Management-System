import "./Category.css"; // Import CSS
import { Link, useNavigate } from "react-router-dom";

function Category() {
  const navigate = useNavigate();

  return (
    <div className="category-container">
      <header className="custom-header">
        <div className="custom-header-bar">
          <div className="custom-container">
            <div className="custom-row">
              <div className="custom-col-left">
                <h1 className="custom-branding">
                  <a href="#">SanFest</a>
                </h1>
              </div>

              <div className="custom-col-right">
                <nav className="custom-navigation">
                  <div className="custom-hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>

                  <ul className="custom-menu">
                    <li><Link to="/index">Home</Link></li>
                    <li><Link to="/category">Events</Link></li>
                    <li><Link to="/organize">Organize</Link></li>
                    <li><a href="#"><i className="fas fa-user-circle" style={{ fontSize: "25px" }}></i></a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Centered Cards Section */}
      <div className="cards-container">
        {/* Row 1 */}
        <div className="card" onClick={() => navigate(`/events?category=music`)}>
        <img src="images/concert.jpg" alt="Music Shows" />
          <h3>Music Shows</h3>
          <Link className="explore-btn">Explore</Link>
        </div>

        <div className="card" onClick={() => navigate(`/events?category=art`)}>
        <img src="images/art.jpg" alt="Cultural and Art Events" />
          <h3>Cultural and Art Events</h3>
          <Link className="explore-btn">Explore</Link>
        </div>

        <div className="card" onClick={() => navigate(`/events?category=conference`)}>
        <img src="images/seminar.jpg" alt="Conference" />
          <h3>Conference</h3>
          <Link className="explore-btn">Explore</Link>
        </div>
      </div>

      {/* New Row for More Categories */}
      <div className="cards-container">
      <div className="card" onClick={() => navigate(`/events?category=sports`)}>
      <img src="images/sports.jpg" alt="Sports Events" />
          <h3>Sports Events</h3>
          <Link className="explore-btn">Explore</Link>
        </div>

        <div className="card" onClick={() => navigate(`/events?category=tech`)}>
        <img src="images/tech.jpg" alt="Tech Meetups" />
          <h3>Tech Meetups</h3>
          <Link className="explore-btn">Explore</Link>
        </div>

        <div className="card" onClick={() => navigate(`/events?category=workshops`)}>
        <img src="images/workshop.jpg" alt="Workshops" />
          <h3>Workshops</h3>
          <Link  className="explore-btn">Explore</Link>
        </div>
      </div>
    </div>
  );
}

export default Category;
