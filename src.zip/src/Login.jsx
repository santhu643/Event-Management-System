import "./assets/css/login.css";
import "./assets/css/gfonts.css";
import {Link} from "react-router-dom";
import {useState,useEffect} from "react";
import {useNavigate} from "react-router-dom";





function Login(){
    const navigate = useNavigate();
    const[email,setEmail] = useState("");
    const[pass,setPass] = useState("");

    function login(e){
        e.preventDefault();
        const data = {email,pass};+
        fetch("http://localhost/ems/backend.php?action=login",{
            method:"POST",
            headers:{"Content-Type":'application/json'},
            body:JSON.stringify(data),
        })
        .then((response)=>response.json())
        .then((data)=>{
            if(data.status==200){
                alert("Success");
                sessionStorage.setItem("user", JSON.stringify(data.user)); // Save user session
                navigate("/index");
            }
            else{
                alert("Invalid credentials");
            }
        })
    }
    
    return(
        
        <div id="regcss">
        <section>
        <form>
            <h1>Login</h1>
            <div className="inputbox">
                <ion-icon name="mail-outline"></ion-icon>
                <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)}  required/>
                <label>Email</label>
            </div>
            <div className="inputbox">
                <ion-icon name="lock-closed-outline"></ion-icon>
                <input type="password" value={pass} onChange={(e)=>setPass(e.target.value)} required/>
                <label>Password</label>
            </div>
            <div className="forget">
                <label><input type="checkbox"/>Remember Me</label>
                <a href="#">Forget Password</a>
            </div>
            <button onClick={login}>Log in</button>
            <div className="register">
                <p>Don't have an account? <Link to="/Register">Register</Link></p>
            </div>
        </form>
    </section>
    </div>
        
        

    )
}

export default Login;