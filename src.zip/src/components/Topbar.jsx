import React from "react";
import { Link } from "react-router-dom";
import "../category.css"; // Using the same CSS as Category page

function TopBar() {
  return (
    <header className="custom-header">
      <div className="custom-header-bar">
        <div className="custom-container">
          <div className="custom-row">
            <div className="custom-col-left">
              <h1 className="custom-branding">
                <a href="#">SanFest</a>
              </h1>
            </div>

            <div className="custom-col-right">
              <nav className="custom-navigation">
                <div className="custom-hamburger">
                  <span></span>
                  <span></span>
                  <span></span>
                  <span></span>
                </div>

                <ul className="custom-menu">
                  <li><Link to="/index">Home</Link></li>
                  <li><Link to="/category">Events</Link></li>
                  <li><Link to="/organize">Organize</Link></li>
                  <li><a href="#"><i className="fas fa-user-circle" style={{ fontSize: "25px" }}></i></a></li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default TopBar;
